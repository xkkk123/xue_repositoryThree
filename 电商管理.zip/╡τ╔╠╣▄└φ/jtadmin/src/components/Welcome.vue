<template>
    <!-- 定义后台欢迎页面 -->
    <div>
      <h1>我是后台欢迎页面</h1>
    </div>
</template>

<script>
</script>

<style>
</style>
