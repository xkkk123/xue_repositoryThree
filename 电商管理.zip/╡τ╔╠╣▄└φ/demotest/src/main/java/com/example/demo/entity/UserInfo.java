package com.example.demo.entity;

public class UserInfo {
    private Integer id;
    private String username;
    private Integer dynamic;
    private Integer concern;
    private Integer fans;
    private String userId;
    private String avatar;
    private Integer sex;
    private String birthday;

    public UserInfo(Integer id, String username, Integer dynamic, Integer concern, Integer fans, String userId, String avatar, Integer sex, String birthday) {
        this.id = id;
        this.username = username;
        this.dynamic = dynamic;
        this.concern = concern;
        this.fans = fans;
        this.userId = userId;
        this.avatar = avatar;
        this.sex = sex;
        this.birthday = birthday;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public Integer getDynamic() {
        return dynamic;
    }

    public void setDynamic(Integer dynamic) {
        this.dynamic = dynamic;
    }

    public Integer getConcern() {
        return concern;
    }

    public void setConcern(Integer concern) {
        this.concern = concern;
    }

    public Integer getFans() {
        return fans;
    }

    public void setFans(Integer fans) {
        this.fans = fans;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getAvatar() {
        return avatar;
    }

    public void setAvatar(String avatar) {
        this.avatar = avatar;
    }

    public Integer getSex() {
        return sex;
    }

    public void setSex(Integer sex) {
        this.sex = sex;
    }

    public String getBirthday() {
        return birthday;
    }

    public void setBirthday(String birthday) {
        this.birthday = birthday;
    }

    @Override
    public String toString() {
        return "UserInfo{" +
                "id=" + id +
                ", username='" + username + '\'' +
                ", dynamic=" + dynamic +
                ", concern=" + concern +
                ", fans=" + fans +
                ", userId='" + userId + '\'' +
                ", avatar='" + avatar + '\'' +
                ", sex=" + sex +
                ", birthday='" + birthday + '\'' +
                '}';
    }
}
