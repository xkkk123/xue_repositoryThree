package com.example.demo.mapper;

import com.example.demo.entity.Article;
import com.example.demo.entity.ArticleInfo;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;

import java.util.List;

@Mapper
public interface ArticleMapper {
    @Select("select art_id from article where title=#{title}")
    String selectArtId(String title);

    @Select("select * from article limit #{pageNum},#{pageSize}")
    List<Article> findPage(int pageNum, int pageSize);

    @Select("select * from articleInfo where art_id=#{atrId}")
    List<ArticleInfo> findArticleInfo(String artId);

    @Select("select * from article where title like #{searchDate}")
    List<Article> findArticle(String searchDate);
}
