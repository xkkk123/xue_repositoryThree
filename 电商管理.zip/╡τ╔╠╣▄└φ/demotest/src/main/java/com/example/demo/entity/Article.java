package com.example.demo.entity;

public class Article {
    private Integer id;
    private String art_id;
    private String title;
    private String aut_id;
    private String comm_count;
    private String pubdate;
    private String aut_name;
    private String images;

    public Article(Integer id, String art_id, String title, String aut_id, String comm_count, String pubdate, String aut_name, String images) {
        this.id = id;
        this.art_id = art_id;
        this.title = title;
        this.aut_id = aut_id;
        this.comm_count = comm_count;
        this.pubdate = pubdate;
        this.aut_name = aut_name;
        this.images = images;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getArt_id() {
        return art_id;
    }

    public void setArt_id(String art_id) {
        this.art_id = art_id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getAut_id() {
        return aut_id;
    }

    public void setAut_id(String aut_id) {
        this.aut_id = aut_id;
    }

    public String getComm_count() {
        return comm_count;
    }

    public void setComm_count(String comm_count) {
        this.comm_count = comm_count;
    }

    public String getPubdate() {
        return pubdate;
    }

    public void setPubdate(String pubdate) {
        this.pubdate = pubdate;
    }

    public String getAut_name() {
        return aut_name;
    }

    public void setAut_name(String aut_name) {
        this.aut_name = aut_name;
    }

    public String getImages() {
        return images;
    }

    public void setImages(String images) {
        this.images = images;
    }

    @Override
    public String toString() {
        return "Article{" +
                "id=" + id +
                ", art_id='" + art_id + '\'' +
                ", title='" + title + '\'' +
                ", aut_id='" + aut_id + '\'' +
                ", comm_count='" + comm_count + '\'' +
                ", pubdate='" + pubdate + '\'' +
                ", aut_name='" + aut_name + '\'' +
                ", images='" + images + '\'' +
                '}';
    }
}
