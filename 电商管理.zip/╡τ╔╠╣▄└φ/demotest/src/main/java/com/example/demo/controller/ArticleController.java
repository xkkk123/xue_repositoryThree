package com.example.demo.controller;

import com.example.demo.entity.Article;
import com.example.demo.entity.ArticleInfo;
import com.example.demo.server.ArticleServer;
import com.example.demo.utils.R;
import com.example.demo.utils.RUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
public class ArticleController {
    @Autowired
    ArticleServer articleServer;

    @GetMapping("/article")
    public List<Article> article(@RequestParam("page") int page, @RequestParam("limit") int limit) {
        List<Article> article = articleServer.findPage(page, limit);
        return article;
    }

    @GetMapping("/selectArticle")
    public R findArticle(@RequestParam("searchDate") String searchDate) {
        String like = "%" + searchDate + "%";
        List<Article> article = articleServer.findArticle(like);
        System.out.println(article);
        if (article.size() == 0) {
            return RUtils.success();
        }
        return RUtils.success(article);
    }

    @GetMapping("/selectArticleInfo")
    public R findArticleInfo(@RequestParam("artId") String artId) {
        List<ArticleInfo> articleInfo = articleServer.findArticleInfo(artId);
        System.out.println(articleInfo);
        return RUtils.success(articleInfo);
    }
}
