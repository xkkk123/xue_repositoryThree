package com.example.demo.server;

import com.example.demo.entity.*;
import com.example.demo.mapper.ArticleMapper;
import com.example.demo.mapper.UserMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class UserServer {
    @Autowired
    UserMapper userMapper;

    public String login(String username, String password) {
        List<User> users = userMapper.findAll();
        System.out.println(username);
        for (User user : users) {
            if (user.getUsername().equals(username) && user.getPassword().equals(password)) {
                return user.getUserId();
            }
        }
        return null;
    }

    public List<UserInfo> findId(String userId) {
        return userMapper.findId(userId);
    }

    public boolean registar(String username, String password, String userId) {
        List<User> users = userMapper.findAll();
        for (User user : users) {
            if (user.getUsername().equals(username)) {
                return false;
            }
        }
        userMapper.registar(username, password, userId);
        userMapper.insertUserinfo(username, userId);
        return true;
    }

    public boolean UpdateUserinfo(String username, String avatar, Integer sex, String birthday, String userId) {
        int result = userMapper.UpdateUserinfo(username, avatar, sex, birthday, userId);
        if (username != null) {
            userMapper.UpdateUsername(username, userId);
        }
        if (result == 1) {
            return true;
        }
        return false;
    }

    public boolean insertHistroy(String title) {
        String artId = userMapper.selectArtId(title);
        System.out.println(artId);
        int i = userMapper.insertHistroy(title, artId);
        if (i == 0) {
            return false;
        }
        return true;
    }

    public List<Histroy> findHistroy() {
        return userMapper.findHistroy();
    }

    public boolean deleteHistroy(String title) {
        int i = userMapper.deleteHistroy(title);
        if (i == 0) {
            return false;
        }
        return true;
    }
}
