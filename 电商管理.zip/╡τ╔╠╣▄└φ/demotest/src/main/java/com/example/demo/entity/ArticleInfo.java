package com.example.demo.entity;

public class ArticleInfo {
    private int id;
    private String art_id;
    private String title;
    private String content;
    private String aut_id;
    private String images;
    private String aut_name;
    private String avatar;

    public ArticleInfo(int id, String art_id, String title, String content, String aut_id, String images, String aut_name, String avatar) {
        this.id = id;
        this.art_id = art_id;
        this.title = title;
        this.content = content;
        this.aut_id = aut_id;
        this.images = images;
        this.aut_name = aut_name;
        this.avatar = avatar;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getArt_id() {
        return art_id;
    }

    public void setArt_id(String art_id) {
        this.art_id = art_id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public String getAut_id() {
        return aut_id;
    }

    public void setAut_id(String aut_id) {
        this.aut_id = aut_id;
    }

    public String getImages() {
        return images;
    }

    public void setImages(String images) {
        this.images = images;
    }

    public String getAut_name() {
        return aut_name;
    }

    public void setAut_name(String aut_name) {
        this.aut_name = aut_name;
    }

    public String getAvatar() {
        return avatar;
    }

    public void setAvatar(String avatar) {
        this.avatar = avatar;
    }

    @Override
    public String toString() {
        return "ArticleInfo{" +
                "id=" + id +
                ", art_id='" + art_id + '\'' +
                ", title='" + title + '\'' +
                ", content='" + content + '\'' +
                ", aut_id='" + aut_id + '\'' +
                ", images='" + images + '\'' +
                ", aut_name='" + aut_name + '\'' +
                ", avatar='" + avatar + '\'' +
                '}';
    }
}
