package com.example.demo.entity;

public class Histroy {
    private Integer id;
    private String title;
    private String art_id;

    public Histroy(Integer id, String title, String art_id) {
        this.id = id;
        this.title = title;
        this.art_id = art_id;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getArt_id() {
        return art_id;
    }

    public void setArt_id(String art_id) {
        this.art_id = art_id;
    }

    @Override
    public String toString() {
        return "Histroy{" +
                "id=" + id +
                ", title='" + title + '\'' +
                ", art_id='" + art_id + '\'' +
                '}';
    }
}
