package com.example.demo.server;

import com.example.demo.entity.Article;
import com.example.demo.entity.ArticleInfo;
import com.example.demo.mapper.ArticleMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ArticleServer {
    @Autowired
    ArticleMapper articleMapper;

    public List<Article> findPage(int page, int limit) {
        int pageNum = (page - 1) * limit;
        List<Article> articles = articleMapper.findPage(pageNum, limit);
        return articles;
    }

    public List<Article> findArticle(String searchDate) {
        List<Article> article = articleMapper.findArticle(searchDate);
        return article;
    }

    public List<ArticleInfo> findArticleInfo(String artId) {
        return articleMapper.findArticleInfo(artId);
    }
}
