package com.example.demo.controller;

import com.alibaba.fastjson.JSONObject;
import com.example.demo.entity.*;
import com.example.demo.server.UserServer;
import com.example.demo.utils.R;
import com.example.demo.utils.RUtils;
import com.example.demo.utils.Renum;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;


@RestController
public class UserController {

    @Autowired
    UserServer userServer;

    @ResponseBody
    @RequestMapping("/login")
    public String login(@RequestBody String s) {
        System.out.println(s);
        String str = "[" + s + "]";
        List<User> users = JSONObject.parseArray(str, User.class);
        User user = users.get(0);
        System.out.println(user);
        String userId = userServer.login(user.getUsername(), user.getPassword());
        if (userId != null) {
            return userId;
        }
        return null;
    }

    @GetMapping("/userInfo")
    public List<UserInfo> userInfoList(@RequestParam("userId") String userId) {
        List<UserInfo> userInfos = userServer.findId(userId);
        return userInfos;
    }

    @ResponseBody
    @RequestMapping("/registar")
    public R registar(@RequestBody String s) {
        String str = "[" + s + "]";
        List<User> users = JSONObject.parseArray(str, User.class);
        User user = users.get(0);
        boolean result = userServer.registar(user.getUsername(), user.getPassword(), user.getUserId());
        if (result) {
            return RUtils.success(Renum.SUCCESS.getCode(), Renum.SUCCESS.getMsg());
        }
        return RUtils.Err(Renum.USER_IS_EXISTS.getCode(), Renum.USER_IS_EXISTS.getMsg());
    }

    @ResponseBody
    @RequestMapping("/updateInfo")
    public R UpdateUserinfo(@RequestBody String s) {
        String str = "[" + s.substring(8, s.length() - 1) + "]";
        List<UserInfo> userInfos = JSONObject.parseArray(str, UserInfo.class);
        UserInfo userInfo = userInfos.get(0);
        System.out.println(userInfos);
        boolean result = userServer.UpdateUserinfo(userInfo.getUsername(), userInfo.getAvatar(), userInfo.getSex(), userInfo.getBirthday(), userInfo.getUserId());
        if (result) {
            return RUtils.success();
        }
        return RUtils.Err(Renum.USER_IS_EXISTS.getCode(), Renum.USER_IS_EXISTS.getMsg());
    }

    @GetMapping("/insertHistroy")
    public R insertHistroy(@RequestParam("title") String title) {
        System.out.println(title);
        boolean b = userServer.insertHistroy(title);
        if (b) {
            return RUtils.success();
        }
        return null;
    }

    @GetMapping("/selectHistroy")
    public R findHistroy() {
        List<Histroy> histroy = userServer.findHistroy();
        if (histroy.size() == 0) {
            return RUtils.success();
        }
        return RUtils.success(histroy);
    }

    @DeleteMapping("/deleteHistroy")
    public R deleteHistroy(@RequestParam("title") String title) {
        boolean b = userServer.deleteHistroy(title);
        if (b) {
            return RUtils.success();
        }
        return RUtils.Err(Renum.DATA_IS_NULL.getCode(), Renum.DATA_IS_NULL.getMsg());
    }

}
