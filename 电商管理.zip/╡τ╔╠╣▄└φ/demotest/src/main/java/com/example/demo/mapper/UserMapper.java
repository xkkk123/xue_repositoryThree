package com.example.demo.mapper;

import com.example.demo.entity.*;
import org.apache.ibatis.annotations.*;


import java.util.List;

@Mapper
public interface UserMapper {
    @Select("select * from user")
    List<User> findAll();

    @Select("select art_id from article where title=#{title}")
    String selectArtId(String title);

    @Select("select * from userinfo where userId=#{userId}")
    List<UserInfo> findId(String userId);

    @Select("select * from article limit #{pageNum},#{pageSize}")
    List<Article> findPage(int pageNum, int pageSize);

    @Select("select * from articleInfo where art_id=#{atrId}")
    List<ArticleInfo> findArticleInfo(String artId);

    @Insert("insert into user (username,password,userId) values(#{username},#{password},#{userId})")
    int registar(String username, String password, String userId);

    @Insert("insert into userinfo (username,userId) values (#{username},#{userId})")
    int insertUserinfo(String username, String userId);

    @Update("<script>" +
            "update userinfo <set>" +
            "<if test='username!=null and username!=\"\"'>username=#{username},</if>" +
            "<if test='avatar!=null and avatar!=\"\"'> avatar=#{avatar},</if>" +
            "<if test='sex!=null'> sex=#{sex},</if>" +
            "<if test='birthday!=null and birthday!=\"\"'>birthday=#{birthday},</if> </set>" +
            "where userId=#{userId}" +
            "</script>")
    int UpdateUserinfo(String username, String avatar, Integer sex, String birthday, String userId);

    @Update("update user set username=#{username} where userId=#{userId}")
    int UpdateUsername(String username, String userId);

    @Select("select * from article where title like #{searchDate}")
    List<Article> findArticle(String searchDate);

    @Insert("insert into histroy (title,art_id) values (#{title},#{art_id})")
    int insertHistroy(String title, String art_id);

    @Select("Select * from histroy")
    List<Histroy> findHistroy();

    @Delete("delete from histroy where title=#{title}")
    int deleteHistroy(String title);
}
